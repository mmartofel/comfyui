#!/bin/bash

python3 main.py --listen=0.0.0.0 --preview-method auto --cpu

exit 0
