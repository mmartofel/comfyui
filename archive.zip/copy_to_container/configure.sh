#!/bin/bash

python3 main.py --disable-auto-launch --cpu

exit 0
