# This archive is to provide to quay.io build system

zip -r archive.zip ./*


